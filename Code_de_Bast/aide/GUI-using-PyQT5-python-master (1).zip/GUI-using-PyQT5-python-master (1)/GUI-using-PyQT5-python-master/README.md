# GUI-using-PyQT5-python
GUI-using-PyQT5-python


tutorial can be found 
https://www.youtube.com/watch?v=ck0a3Uy9jrM&feature=youtu.be

